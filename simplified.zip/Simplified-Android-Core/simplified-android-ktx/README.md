org.librarysimplified.android.ktx
===

Kotlin Android Extensions for the Library Simplified project.
