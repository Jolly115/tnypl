package org.nypl.simplified.ui.splash

sealed class SplashEvent {

  object SplashCompleted : SplashEvent()
}
