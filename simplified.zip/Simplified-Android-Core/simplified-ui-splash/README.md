org.librarysimplified.ui.splash
===

The `org.librarysimplified.ui.splash` module contains user interface
code related to the _splash screen_.
