org.librarysimplified.reader.bookmarks.api
===

The `org.librarysimplified.reader.bookmarks.api` module specifies an
API for managing bookmarks in EPUB readers.
