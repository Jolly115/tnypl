package org.nypl.simplified.cardcreator.model

enum class Location {
  New_York_City,
  New_York_State,
  Us
}
