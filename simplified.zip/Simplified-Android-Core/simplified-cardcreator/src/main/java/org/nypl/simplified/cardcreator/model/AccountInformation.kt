package org.nypl.simplified.cardcreator.model

data class AccountInformation(val username: String, val pin: String)
