package org.nypl.simplified.cardcreator.model

data class PersonalInformation(
  val firstName: String,
  val middleName: String,
  val lastName: String,
  val birthDate: String,
  val email: String
)
