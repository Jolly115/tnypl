package org.nypl.simplified.cardcreator.model

/**
 * Three types of address types
 */
enum class AddressType {
  HOME, WORK, SCHOOL
}
