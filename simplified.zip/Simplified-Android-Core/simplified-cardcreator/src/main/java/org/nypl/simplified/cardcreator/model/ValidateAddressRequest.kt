package org.nypl.simplified.cardcreator.model

data class ValidateAddressRequest(
  val address: Address,
)
