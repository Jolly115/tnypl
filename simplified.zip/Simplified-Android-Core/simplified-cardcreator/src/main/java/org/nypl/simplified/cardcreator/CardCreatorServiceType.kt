package org.nypl.simplified.cardcreator

interface CardCreatorServiceType {

  fun getCardCreatorContract(): CardCreatorContract
}
