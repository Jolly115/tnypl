package org.nypl.simplified.accounts.api

import org.nypl.simplified.presentableerror.api.PresentableType

/**
 * The type of account events.
 */

abstract class AccountEvent : PresentableType
