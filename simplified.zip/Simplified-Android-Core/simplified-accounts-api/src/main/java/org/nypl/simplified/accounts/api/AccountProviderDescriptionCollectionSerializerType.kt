package org.nypl.simplified.accounts.api

import org.nypl.simplified.parser.api.SerializerType

/**
 * A serializer of account provider description collections.
 */

interface AccountProviderDescriptionCollectionSerializerType : SerializerType
