package org.nypl.simplified.accounts.api

/**
 * An account username.
 */

data class AccountUsername(val value: String)
