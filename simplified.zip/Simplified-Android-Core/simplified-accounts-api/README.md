org.librarysimplified.accounts.api
===

The `org.librarysimplified.accounts.api` module specifies the types
and interfaces related to _accounts_.
