/**
 * CI tools (Commits-since-last-release checker).
 */

package org.librarysimplified.ci.check_commits_since;
