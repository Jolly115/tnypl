org.librarysimplified.parser.api
===

The `org.librarysimplified.parser.api` module specifies a generic
parser API. This API is typically extended by other parsing-related APIs
throughout the application, and can be useful for enumerating parsers.
