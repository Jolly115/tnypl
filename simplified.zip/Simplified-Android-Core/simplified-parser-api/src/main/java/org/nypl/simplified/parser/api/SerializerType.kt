package org.nypl.simplified.parser.api

/**
 * A generic serializer.
 */

interface SerializerType {

  fun serialize()
}
