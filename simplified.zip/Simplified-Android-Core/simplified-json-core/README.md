org.librarysimplified.json.core
===

The `org.librarysimplified.json.core` module provides a set of classes
for working with JSON.
