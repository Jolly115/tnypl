org.librarysimplified.ui.onboarding
===

The `org.librarysimplified.ui.onboarding` module contains user interface
code related to the _onboarding_.
