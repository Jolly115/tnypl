org.librarysimplified.main
===

The `org.librarysimplified.main` module provides the main entry point
for applications.
