package org.nypl.simplified.main

import org.nypl.simplified.ui.thread.api.UIThreadServiceType

/**
 * UI thread service.
 */

class MainUIThreadService : UIThreadServiceType
