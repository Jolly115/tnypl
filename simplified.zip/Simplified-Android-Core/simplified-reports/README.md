org.librarysimplified.reports
===

The `org.librarysimplified.reports` module provides methods for
formatting and sending _error reports_.
