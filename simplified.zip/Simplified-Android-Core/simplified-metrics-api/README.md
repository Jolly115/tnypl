org.librarysimplified.metrics.api
=================================

The `org.librarysimplified.metrics.api` module provides
a trivial API to log analytic events
