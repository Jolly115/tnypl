package org.nypl.simplified.opds2.parser.api

import org.nypl.simplified.opds2.OPDS2Feed
import org.nypl.simplified.parser.api.ParserProviderType

interface OPDS2ParsersType : ParserProviderType<OPDS2Feed>
