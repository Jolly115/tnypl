org.librarysimplified.opds2.parser.api
===

The `org.librarysimplified.opds2.parser.api` module provides a parser interface for OPDS 2.0 feeds.

#### See Also

* [OPDS 2.0](https://drafts.opds.io/opds-2.0)
