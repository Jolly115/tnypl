[OE-515] - [Android] Terms of Use screen
[OE-516] - [Android] Privacy policy page
[OE-517] - [Android] Redesign the login screen
[OE-552] - [UX] Create sign in designs in dark mode for iOS and Android