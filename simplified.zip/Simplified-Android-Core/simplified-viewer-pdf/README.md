org.librarysimplified.viewer.pdf
===

The `org.librarysimplified.viewer.pdf` module is an implementation
of the [Viewer SPI](../simplified-viewer-spi/README.md) that uses 
Minitex's PDF API to display PDF files.

#### See Also

* [PDF](https://github.com/Minitex/pdfreader-android)
* [org.librarysimplified.viewer.spi](../simplified-viewer-spi/README.md)
