org.librarysimplified.ui.profiles
===

The `org.librarysimplified.ui.profiles` module provides user interface
code related to _user profiles_.

#### See Also

* [org.librarysimplified.profiles.api](../simplified-profiles-api/README.md)
