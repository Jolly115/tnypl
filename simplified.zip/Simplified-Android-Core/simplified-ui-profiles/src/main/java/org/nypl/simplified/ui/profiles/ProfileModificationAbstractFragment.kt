package org.nypl.simplified.ui.profiles

import androidx.fragment.app.Fragment

abstract class ProfileModificationAbstractFragment : Fragment()
