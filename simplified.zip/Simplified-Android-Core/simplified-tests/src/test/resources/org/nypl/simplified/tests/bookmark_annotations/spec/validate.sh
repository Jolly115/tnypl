#!/bin/sh
exec java -cp json-schema-validator-2.2.14-lib.jar Validate.java "$@"
