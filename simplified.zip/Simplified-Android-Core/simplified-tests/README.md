org.librarysimplified.tests
===

The `org.librarysimplified.tests` module provides the automated test
suite for the project.
